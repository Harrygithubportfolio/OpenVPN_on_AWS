
import boto3

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    ec2.stop_instances(InstanceIds=['i-08f2a77b37e906a19'])
    print("Stopped instance: i-08f2a77b37e906a19")
        