
import boto3

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    ec2.stop_instances(InstanceIds=['i-0fcffbce5c9897380'])
    print("Stopped instance: i-0fcffbce5c9897380")
        